
    const Words=['yo1','yo2','yo3']

export default Words;