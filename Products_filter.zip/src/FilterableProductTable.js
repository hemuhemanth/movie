import { useState } from "react";
import SearchBar from "./SearchBar";
import ProductTable from "./ProductTable";
//import ProductCategoryRow from "./ProductCategoryRow";
function FilterableProductTable(props){
  /* const [state,setState]=useState({
    filterText:'',
    inStockOnly : false
});*/
const [filterText,setFilterText]=useState('');
const [inStockOnly,setInstockOnly]=useState(false);
//const [onFilterTextChange,setonFilterTextChange]=useState();

function handleFilterTextChange(filterText) {
setFilterText(filterText);
console.log(filterText);
}
function handleInStockChange(inStockOnly) {
  if(inStockOnly===true){
    setInstockOnly(false);
  }
  else{
    setInstockOnly(true);
  }
  //setInstockOnly({setInstockOnly});
    console.log({setInstockOnly});
   
}
return (
    <div>
      <SearchBar 
      filterText={filterText}
          inStockOnly={inStockOnly}
          onFilterTextChange={handleFilterTextChange}
          onInStockChange={handleInStockChange}
        />
       
        <ProductTable
          products={props.products}
          filterText={filterText}
          inStockOnly={inStockOnly}
          //onFilterTextChange={handleFilterTextChange}
          
        />
         {console.log(inStockOnly)}
       
      </div>
    );

}
export default FilterableProductTable;